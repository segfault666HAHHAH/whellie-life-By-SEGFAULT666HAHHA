# Wheelie Rush (SpriteKit, iOS 16+)

Original wheelie-balance game: hold GAS to lift the front wheel, BRAKE to bring it down,
TRICK for bonus points. Earn money, buy bikes / paint / helmets.

Options screen: FULLSCREEN (LANDSCAPE) toggle + screen shape (FULL, 21:9, 16:9, 3:2, 4:3).

## Get the unsigned .ipa (no Mac needed)
1. Create a free GitHub account and a new repository.
2. Upload this whole project (or just the zip + the workflow file, see below).
3. Open the repo > Actions > "Build unsigned IPA" > Run workflow.
4. When it finishes (about 3-6 min) open the run, download the artifact "WheelieRush-IPA".
5. Unzip it, import WheelieRush.ipa into KSign, sign and install.

Phone-friendly route: upload `WheelieRush-project.zip` to the repo root, then create the file
`.github/workflows/build.yml` (Add file > Create new file, type the whole path) and paste in build.yml.
The workflow unzips the project itself.

Tuning numbers are at the top of Sources/GameScene.swift.
