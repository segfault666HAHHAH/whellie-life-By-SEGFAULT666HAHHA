import SpriteKit
import UIKit

/// Loads PNG art. Lookup order:
///  1. Files app -> On My iPhone -> (this app) -> Assets/<name>.png   (your own custom art)
///  2. The Assets folder packed inside the app
///  3. nil (the game then draws a plain coloured shape instead)
enum Assets {
    private static var cache: [String: SKTexture] = [:]

    static func texture(_ name: String) -> SKTexture? {
        if let t = cache[name] { return t }
        var image: UIImage?
        let fm = FileManager.default
        if let docs = fm.urls(for: .documentDirectory, in: .userDomainMask).first {
            let p = docs.appendingPathComponent("Assets").appendingPathComponent(name + ".png").path
            if fm.fileExists(atPath: p) { image = UIImage(contentsOfFile: p) }
        }
        if image == nil, let p = Bundle.main.path(forResource: name, ofType: "png", inDirectory: "Assets") {
            image = UIImage(contentsOfFile: p)
        }
        guard let img = image else { return nil }
        let t = SKTexture(image: img)
        cache[name] = t
        return t
    }

    static func sprite(_ name: String, size: CGSize, fallback: UIColor) -> SKSpriteNode {
        if let t = texture(name) {
            let s = SKSpriteNode(texture: t)
            s.size = size
            return s
        }
        return SKSpriteNode(color: fallback, size: size)
    }

    /// Creates the Documents/Assets folder so it shows up in the Files app.
    static func prepareDocuments() {
        let fm = FileManager.default
        guard let docs = fm.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let dir = docs.appendingPathComponent("Assets")
        if !fm.fileExists(atPath: dir.path) {
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        let readme = dir.appendingPathComponent("README.txt")
        if !fm.fileExists(atPath: readme.path),
           let src = Bundle.main.path(forResource: "README", ofType: "txt", inDirectory: "Assets") {
            try? fm.copyItem(atPath: src, toPath: readme.path)
        }
    }
}
