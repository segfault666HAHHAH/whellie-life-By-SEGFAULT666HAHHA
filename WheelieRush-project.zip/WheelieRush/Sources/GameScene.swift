import SpriteKit

/// Scrolling, tiled background strip.
final class ScrollLayer {
    let node = SKNode()
    private var sprites: [SKSpriteNode] = []
    private let tileW: CGFloat
    private var offset: CGFloat = 0

    init(textureName: String, tileSize: CGSize, anchor: CGPoint, y: CGFloat, viewWidth: CGFloat, fallback: UIColor) {
        tileW = tileSize.width
        let count = Int(ceil(viewWidth / tileSize.width)) + 2
        for i in 0..<count {
            let s: SKSpriteNode
            if let t = Assets.texture(textureName) {
                s = SKSpriteNode(texture: t)
            } else {
                s = SKSpriteNode(color: fallback, size: tileSize)
            }
            s.size = CGSize(width: tileSize.width + 1, height: tileSize.height)
            s.anchorPoint = anchor
            s.position = CGPoint(x: CGFloat(i) * tileSize.width, y: y)
            node.addChild(s)
            sprites.append(s)
        }
    }

    func scroll(by dx: CGFloat) {
        offset = (offset + dx).truncatingRemainder(dividingBy: tileW)
        for (i, s) in sprites.enumerated() {
            s.position.x = CGFloat(i) * tileW - offset
        }
    }
}

final class GameScene: BaseScene {
    private enum Zone { case gas, brake, trick }

    // ===== TUNING: change these numbers to make the game easier / harder =====
    private let balanceAngle: CGFloat = 62     // angle (deg) where the bike is perfectly balanced
    private let crashAngle: CGFloat = 86       // flip over past this angle
    private let gasTorque: CGFloat = 230       // how hard GAS lifts the front wheel
    private let brakeTorque: CGFloat = 140     // how hard BRAKE pulls it back down
    private let gravityTorque: CGFloat = 140   // how hard gravity pulls
    private let damping: CGFloat = 1.4         // smoothness
    private let throttleUp: CGFloat = 3.2      // how fast gas ramps up
    private let throttleDown: CGFloat = 5.0    // how fast gas ramps down
    // =========================================================================

    private let spec: BikeSpec
    private var bike: BikeNode!
    private var bikeScale: CGFloat = 1
    private var farLayer: ScrollLayer!
    private var roadLayer: ScrollLayer!
    private var pxPerKmh: CGFloat = 4

    private var theta: CGFloat = 0      // wheelie angle in degrees
    private var omega: CGFloat = 0      // degrees per second
    private var speed: CGFloat = 0      // km/h
    private var throttle: CGFloat = 0
    private var score: CGFloat = 0
    private var elapsed: TimeInterval = 0
    private var lastTime: TimeInterval = 0
    private var crashed = false
    private var paused = false
    private var tricking = false

    private var active: [UITouch: Zone] = [:]
    private var gasHeld: Bool { active.values.contains(.gas) }
    private var brakeHeld: Bool { active.values.contains(.brake) }

    private var timeLabel: SKLabelNode!
    private var speedLabel: SKLabelNode!
    private var scoreLabel: SKLabelNode!
    private var warnLabel: SKLabelNode!
    private var hintLabel: SKLabelNode?
    private var pauseButton: Button!
    private var rectGas = CGRect.zero, rectBrake = CGRect.zero, rectTrick = CGRect.zero

    init(size: CGSize, spec: BikeSpec) {
        self.spec = spec
        super.init(size: size)
    }

    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    // MARK: Setup
    override func didMove(to view: SKView) {
        view.isMultipleTouchEnabled = true
        addBackground()
        setupWorld()
        setupBike()
        setupHUD()
        setupControls()
    }

    private func setupWorld() {
        let w = size.width, h = size.height
        bikeScale = min(w * 0.55 / 480, h * 0.34 / 200)
        pxPerKmh = bikeScale * 9
        let roadScale = bikeScale * (isLandscape ? 1.2 : 1.5)
        let roadTop = h * (isLandscape ? 0.60 : 0.42)

        let farH = max(120, (h - roadTop) * 0.9)
        let farScale = farH / 400
        farLayer = ScrollLayer(textureName: "bg_far", tileSize: CGSize(width: 1024 * farScale, height: farH),
                               anchor: .zero, y: roadTop - 10, viewWidth: w, fallback: UIColor(red: 0.3, green: 0.65, blue: 0.4, alpha: 1))
        farLayer.node.zPosition = -50
        addChild(farLayer.node)

        roadLayer = ScrollLayer(textureName: "road", tileSize: CGSize(width: 1024 * roadScale, height: 320 * roadScale),
                                anchor: CGPoint(x: 0, y: 1), y: roadTop, viewWidth: w, fallback: UIColor(white: 0.25, alpha: 1))
        roadLayer.node.zPosition = -10
        addChild(roadLayer.node)

        groundY = roadTop - 150 * roadScale
    }

    private var groundY: CGFloat = 0

    private func setupBike() {
        let paint = Catalog.paints[min(Store.shared.selectedPaint, Catalog.paints.count - 1)].color
        bike = BikeNode(bike: spec, paintColor: paint, helmetId: Store.shared.selectedHelmet, withRider: true)
        bike.setScale(bikeScale)
        bike.position = CGPoint(x: size.width * 0.22, y: groundY)
        bike.zPosition = 10
        addChild(bike)
    }

    private func setupHUD() {
        let w = size.width, h = size.height
        let top = h - max(inset.top, 14) - 10
        let left = max(inset.left, 16) + 12

        timeLabel = makeLabel("00:00", size: 40, color: .black, align: .left)
        timeLabel.position = CGPoint(x: left, y: top - 22)
        timeLabel.zPosition = 100
        addChild(timeLabel)

        speedLabel = makeLabel("0 KM/H", size: 20, color: .black, align: .left)
        speedLabel.position = CGPoint(x: left, y: top - 58)
        speedLabel.zPosition = 100
        addChild(speedLabel)

        scoreLabel = makeLabel("SCORE 0", size: 26, color: .black)
        scoreLabel.position = CGPoint(x: w / 2, y: top - 24)
        scoreLabel.zPosition = 100
        addChild(scoreLabel)

        warnLabel = makeLabel("TOO HIGH! BRAKE!", size: 26, color: Theme.red)
        warnLabel.position = CGPoint(x: w / 2, y: top - 62)
        warnLabel.zPosition = 100
        warnLabel.isHidden = true
        addChild(warnLabel)

        pauseButton = Button(text: "II", size: CGSize(width: 50, height: 50), fill: UIColor(white: 0.1, alpha: 0.75))
        pauseButton.position = CGPoint(x: w - max(inset.right, 16) - 36, y: top - 28)
        pauseButton.zPosition = 100
        pauseButton.onTap = { [weak self] in self?.pause() }
        addChild(pauseButton)

        let hint = makeLabel(isLandscape ? "HOLD GAS TO LIFT THE FRONT WHEEL - BRAKE TO BALANCE" : "HOLD GAS - BRAKE TO BALANCE", size: 18, color: .black)
        hint.position = CGPoint(x: w / 2, y: h * 0.64)
        hint.zPosition = 100
        addChild(hint)
        hintLabel = hint
        hint.run(SKAction.sequence([SKAction.wait(forDuration: 5), SKAction.fadeOut(withDuration: 0.6), SKAction.removeFromParent()]))
    }

    private func setupControls() {
        let w = size.width, h = size.height
        let m: CGFloat = 10
        let bh = h * (isLandscape ? 0.34 : 0.20)
        let l = max(inset.left, m), r = max(inset.right, m), b = max(inset.bottom, m)
        let half = (w - l - r - m) / 2
        rectBrake = CGRect(x: l, y: b, width: half, height: bh)
        rectGas = CGRect(x: l + half + m, y: b, width: half, height: bh)
        let ty = h * (isLandscape ? 0.46 : 0.60)
        rectTrick = CGRect(x: l + w * 0.1, y: ty, width: w - l - r - w * 0.2, height: h * 0.14)

        for (rect, text) in [(rectBrake, "BRAKE"), (rectGas, "GAS !!!"), (rectTrick, "TRICK")] {
            let s = SKShapeNode(rect: rect, cornerRadius: 14)
            s.fillColor = UIColor(white: 1, alpha: 0.18)
            s.strokeColor = UIColor(white: 1, alpha: 0.35)
            s.lineWidth = 2
            s.zPosition = 90
            addChild(s)
            let lb = makeLabel(text, size: min(rect.height * 0.35, 40))
            lb.position = CGPoint(x: rect.midX, y: rect.midY)
            lb.zPosition = 91
            addChild(lb)
        }
    }

    // MARK: Touches
    private func zone(at p: CGPoint) -> Zone? {
        if rectGas.contains(p) { return .gas }
        if rectBrake.contains(p) { return .brake }
        if rectTrick.contains(p) { return .trick }
        return nil
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let p = t.location(in: self)
            if modalRoot != nil || button(at: p) != nil {
                super.touchesBegan([t], with: event)
                continue
            }
            guard !crashed, !paused, let z = zone(at: p) else { continue }
            if z == .trick { doTrick() } else { active[t] = z }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            if active.removeValue(forKey: t) == nil { super.touchesEnded([t], with: event) }
        }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            if active.removeValue(forKey: t) == nil { super.touchesCancelled([t], with: event) }
        }
    }

    // MARK: Game loop
    override func update(_ currentTime: TimeInterval) {
        var dt = lastTime == 0 ? 0 : currentTime - lastTime
        lastTime = currentTime
        dt = min(dt, 1.0 / 20.0)
        guard dt > 0, !paused else { return }
        step(CGFloat(dt))
    }

    private func step(_ dt: CGFloat) {
        if crashed {
            speed *= pow(0.03, dt)
            scrollWorld(dt)
            return
        }
        elapsed += TimeInterval(dt)

        // throttle ramps smoothly
        let target: CGFloat = gasHeld ? 1 : 0
        if throttle < target { throttle = min(target, throttle + throttleUp * dt) }
        else { throttle = max(target, throttle - throttleDown * dt) }

        // speed
        speed += (spec.topSpeed - speed) * 0.55 * throttle * dt
        speed -= 4 * dt
        if brakeHeld { speed -= 75 * dt }
        speed = max(0, min(spec.topSpeed, speed))

        // wheelie physics
        let rad: CGFloat = .pi / 180
        let speedFactor = 0.4 + 0.6 * min(1, speed / 30)
        var alpha = gasTorque * spec.power * throttle * speedFactor
        alpha += gravityTorque * sin((theta - balanceAngle) * rad)
        if brakeHeld { alpha -= brakeTorque }
        alpha -= damping * omega
        omega += alpha * dt
        theta += omega * dt
        if theta <= 0 {
            theta = 0
            if omega < 0 { omega = 0 }
        }

        if theta >= crashAngle {
            crash()
            return
        }

        // score: only counts while the front wheel is up
        if theta > 12 && speed > 8 {
            score += (speed / 12) * (theta / 30) * spec.scoreMult * dt * 2.5
        }

        bike.zRotation = theta * rad
        bike.spinWheels(speed * 0.25 * dt)
        scrollWorld(dt)
        updateHUD()
    }

    private func scrollWorld(_ dt: CGFloat) {
        let dx = speed * pxPerKmh * dt
        roadLayer.scroll(by: dx)
        farLayer.scroll(by: dx * 0.12)
        if crashed { bike.spinWheels(speed * 0.25 * dt) }
    }

    private func updateHUD() {
        timeLabel.text = String(format: "%02d:%02d", Int(elapsed) / 60, Int(elapsed) % 60)
        speedLabel.text = "\(Int(speed)) KM/H"
        scoreLabel.text = "SCORE \(Int(score))"
        warnLabel.isHidden = !(theta > balanceAngle + 6)
    }

    // MARK: Trick
    private func doTrick() {
        guard !tricking, theta > 20 else { return }
        tricking = true
        omega += 25
        let up = SKAction.moveBy(x: 0, y: 26, duration: 0.18)
        let down = SKAction.moveBy(x: 0, y: -26, duration: 0.18)
        let tilt = SKAction.rotate(byAngle: 0.12, duration: 0.18)
        bike.riderGroup.run(SKAction.sequence([
            SKAction.group([up, tilt]), SKAction.wait(forDuration: 0.35),
            SKAction.group([down, tilt.reversed()])
        ]))
        run(SKAction.sequence([SKAction.wait(forDuration: 0.8), SKAction.run { [weak self] in
            guard let self = self else { return }
            self.tricking = false
            if !self.crashed {
                let bonus = 40 * self.spec.scoreMult
                self.score += bonus
                self.popText("+\(Int(bonus)) TRICK!")
            }
        }]), withKey: "trick")
    }

    private func popText(_ text: String) {
        let l = makeLabel(text, size: 30, color: Theme.yellow)
        l.position = CGPoint(x: size.width * 0.5, y: size.height * 0.52)
        l.zPosition = 200
        addChild(l)
        l.run(SKAction.sequence([
            SKAction.group([SKAction.moveBy(x: 0, y: 60, duration: 0.9), SKAction.fadeOut(withDuration: 0.9)]),
            SKAction.removeFromParent()
        ]))
    }

    // MARK: Crash
    private func crash() {
        crashed = true
        removeAction(forKey: "trick")
        active.removeAll()
        warnLabel.isHidden = true

        // bike falls over backwards
        let fall = SKAction.group([
            SKAction.rotate(toAngle: 2.5, duration: 0.7, shortestUnitArc: false),
            SKAction.moveBy(x: -size.width * 0.06, y: 0, duration: 0.7)
        ])
        fall.timingMode = .easeOut
        bike.run(fall)

        // rider is thrown off
        let center = bike.convert(BikeNode.bodyCenter, to: self)
        let pivot = SKNode()
        pivot.position = center
        pivot.setScale(bikeScale)
        pivot.zRotation = bike.zRotation
        pivot.zPosition = 20
        addChild(pivot)
        bike.riderGroup.removeFromParent()
        bike.riderGroup.position = CGPoint(x: -BikeNode.bodyCenter.x, y: -BikeNode.bodyCenter.y)
        bike.riderGroup.zPosition = 0
        pivot.addChild(bike.riderGroup)
        let rise = SKAction.moveBy(x: 0, y: size.height * 0.10, duration: 0.35)
        rise.timingMode = .easeOut
        let drop = SKAction.moveBy(x: 0, y: -size.height * 0.12, duration: 0.40)
        drop.timingMode = .easeIn
        let drift = SKAction.moveBy(x: -size.width * 0.30, y: 0, duration: 0.75)
        pivot.run(SKAction.group([
            SKAction.sequence([rise, drop]),
            drift,
            SKAction.rotate(byAngle: .pi * 3, duration: 0.75)
        ]))

        let earned = Int(score / 2)
        let final = Int(score)
        let isBest = final > Store.shared.best
        if isBest { Store.shared.best = final }
        Store.shared.money += earned

        run(SKAction.sequence([SKAction.wait(forDuration: 1.2), SKAction.run { [weak self] in
            self?.showOverlay(title: "CRASH!",
                              lines: ["SCORE: \(final)" + (isBest ? "  NEW BEST!" : ""), "BEST: \(Store.shared.best)", "EARNED: $\(earned)"],
                              buttons: [
                                ("RETRY", Theme.green, { Router.shared.show(.game) }),
                                ("GARAGE", Theme.blue, { Router.shared.show(.garage) }),
                                ("MENU", Theme.darkBlue, { Router.shared.show(.menu) })
                              ])
        }]))
    }

    // MARK: Pause
    private func pause() {
        guard !crashed, !paused else { return }
        paused = true
        active.removeAll()
        showOverlay(title: "PAUSED", lines: [], buttons: [
            ("RESUME", Theme.green, { [weak self] in
                self?.closeOverlay()
                self?.paused = false
                self?.lastTime = 0
            }),
            ("RESTART", Theme.blue, { Router.shared.show(.game) }),
            ("MENU", Theme.darkBlue, { Router.shared.show(.menu) })
        ])
    }
}
