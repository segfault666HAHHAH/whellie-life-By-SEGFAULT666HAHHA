import SpriteKit

final class MenuScene: BaseScene {
    override func didMove(to view: SKView) {
        addBackground()
        let w = size.width, h = size.height

        // far scenery strip at the bottom
        if let t = Assets.texture("bg_far") {
            let s = SKSpriteNode(texture: t)
            let sc = w / 1024
            s.size = CGSize(width: w, height: 400 * sc)
            s.anchorPoint = .zero
            s.position = .zero
            s.zPosition = -50
            addChild(s)
        }

        let fs = isLandscape ? min(h * 0.17, 80) : min(w * 0.17, 80)
        if isLandscape {
            let t = outlinedLabel("WHEELIE RUSH", size: fs, color: Theme.yellow)
            t.position = CGPoint(x: w / 2, y: h * 0.76)
            addChild(t)
        } else {
            let a = outlinedLabel("WHEELIE", size: fs, color: Theme.yellow)
            a.position = CGPoint(x: w / 2, y: h * 0.80)
            addChild(a)
            let b = outlinedLabel("RUSH", size: fs * 1.15, color: UIColor(red: 1, green: 0.5, blue: 0.2, alpha: 1))
            b.position = CGPoint(x: w / 2, y: h * 0.80 - fs * 1.05)
            addChild(b)
        }

        let best = makeLabel("BEST SCORE: \(Store.shared.best)", size: isLandscape ? 22 : 26, color: .black)
        best.position = CGPoint(x: w / 2, y: isLandscape ? h * 0.57 : h * 0.55)
        addChild(best)

        let bw = min(w * 0.6, 300)
        let bh = max(46, min(h * 0.085, 62))
        let play = Button(text: "PLAY", size: CGSize(width: bw, height: bh * 1.15), fill: Theme.blue)
        play.onTap = { Router.shared.show(.game) }
        let garage = Button(text: "GARAGE", size: CGSize(width: bw * 0.85, height: bh), fill: Theme.blue)
        garage.onTap = { Router.shared.show(.garage) }
        let options = Button(text: "OPTIONS", size: CGSize(width: bw * 0.85, height: bh), fill: Theme.blue)
        options.onTap = { Router.shared.show(.options) }

        if isLandscape {
            let y = h * 0.34
            play.position = CGPoint(x: w / 2, y: y)
            garage.position = CGPoint(x: w / 2 - bw * 0.95, y: y)
            options.position = CGPoint(x: w / 2 + bw * 0.95, y: y)
        } else {
            play.position = CGPoint(x: w / 2, y: h * 0.42)
            garage.position = CGPoint(x: w / 2, y: h * 0.42 - bh * 1.5)
            options.position = CGPoint(x: w / 2, y: h * 0.42 - bh * 2.7)
        }
        addChild(play); addChild(garage); addChild(options)
    }
}
