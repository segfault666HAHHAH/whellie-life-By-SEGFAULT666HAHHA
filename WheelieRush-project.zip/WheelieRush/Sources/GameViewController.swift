import SpriteKit
import UIKit

final class Router {
    static let shared = Router()
    weak var vc: GameViewController?
    func show(_ s: Screen) { vc?.show(s) }
    func applyOrientation() { vc?.applyOrientation() }
    func relayout() { vc?.relayout() }
}

final class GameViewController: UIViewController {
    private let skView = SKView()
    private var current: Screen = .menu
    private var lastSize: CGSize = .zero

    override func loadView() {
        let v = UIView()
        v.backgroundColor = .black
        view = v
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        skView.isMultipleTouchEnabled = true
        skView.ignoresSiblingOrder = true
        skView.backgroundColor = .black
        view.addSubview(skView)
        Router.shared.vc = self
        Assets.prepareDocuments()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let f = fittedFrame()
        if skView.frame != f { skView.frame = f }
        if f.width > 0, f.height > 0, f.size != lastSize {
            lastSize = f.size
            showScreen(current, animated: false)
        }
    }

    // Letterbox the game into the chosen shape (4:3, 16:9 ...). "FULL" uses the whole screen.
    private func fittedFrame() -> CGRect {
        let b = view.bounds
        guard b.width > 0, b.height > 0, var r = Store.ratios[Store.shared.ratioIndex].value else { return b }
        if b.width <= b.height { r = 1 / r }
        var w = b.width
        var h = b.height
        if b.width / b.height > r { w = b.height * r } else { h = b.width / r }
        return CGRect(x: (b.width - w) / 2, y: (b.height - h) / 2, width: w, height: h).integral
    }

    func show(_ s: Screen) { showScreen(s, animated: true) }

    private func showScreen(_ s: Screen, animated: Bool) {
        current = s
        let size = skView.bounds.size
        guard size.width > 0, size.height > 0 else { return }
        let scene: SKScene
        switch s {
        case .menu:    scene = MenuScene(size: size)
        case .garage:  scene = GarageScene(size: size)
        case .options: scene = OptionsScene(size: size)
        case .game:    scene = GameScene(size: size, spec: Catalog.bike(Store.shared.selectedBike))
        }
        if animated {
            skView.presentScene(scene, transition: SKTransition.fade(withDuration: 0.2))
        } else {
            skView.presentScene(scene)
        }
    }

    // MARK: Orientation ("fullscreen" = landscape)
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        Store.shared.landscape ? .landscape : .portrait
    }
    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }

    func applyOrientation() {
        setNeedsUpdateOfSupportedInterfaceOrientations()
        let mask: UIInterfaceOrientationMask = Store.shared.landscape ? .landscape : .portrait
        if let ws = view.window?.windowScene {
            ws.requestGeometryUpdate(.iOS(interfaceOrientations: mask)) { _ in }
        }
    }

    func relayout() {
        view.setNeedsLayout()
        view.layoutIfNeeded()
    }
}
