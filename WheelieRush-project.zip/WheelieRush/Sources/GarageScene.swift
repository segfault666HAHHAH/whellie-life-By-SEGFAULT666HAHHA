import SpriteKit

private struct PanelItem {
    var color: UIColor? = nil
    var texture: SKTexture? = nil
    var price: Int
    var owned: Bool
    var selected: Bool
    var action: () -> Void
}

final class GarageScene: BaseScene {
    private let store = Store.shared
    private var index = 0
    private let holder = SKNode()
    private var moneyLabel: SKLabelNode!
    private var nameLabel: SKLabelNode!
    private var statsLabel: SKLabelNode!
    private var actionButton: Button!
    private var panelRoot: SKNode?

    override func didMove(to view: SKView) {
        index = Catalog.bikes.firstIndex { $0.id == store.selectedBike } ?? 0
        addBackground()
        build()
        refresh()
    }

    private func build() {
        let w = size.width, h = size.height
        let top = h - max(inset.top, 16) - 34
        let left = max(inset.left, 16) + 30

        let back = Button(text: "BACK", size: CGSize(width: 90, height: 46), fill: Theme.blue)
        back.position = CGPoint(x: left + 15, y: top)
        back.onTap = { Router.shared.show(.menu) }
        addChild(back)

        let moneyBg = SKShapeNode(rectOf: CGSize(width: min(w * 0.45, 200), height: 46), cornerRadius: 12)
        moneyBg.fillColor = UIColor(red: 0.1, green: 0.2, blue: 0.35, alpha: 1)
        moneyBg.strokeColor = .black
        moneyBg.lineWidth = 3
        moneyBg.position = CGPoint(x: w - max(inset.right, 16) - min(w * 0.45, 200) / 2, y: top)
        addChild(moneyBg)
        moneyLabel = makeLabel("", size: 26, color: .white, align: .right)
        moneyLabel.position = CGPoint(x: min(w * 0.45, 200) / 2 - 14, y: 0)
        moneyBg.addChild(moneyLabel)

        let row = top - 62
        let paint = Button(text: "PAINT", size: CGSize(width: 110, height: 46), fill: Theme.purple)
        paint.position = CGPoint(x: w / 2 - 66, y: row)
        paint.onTap = { [weak self] in self?.showPaintPanel() }
        addChild(paint)
        let helmet = Button(text: "HELMET", size: CGSize(width: 110, height: 46), fill: Theme.purple)
        helmet.position = CGPoint(x: w / 2 + 66, y: row)
        helmet.onTap = { [weak self] in self?.showHelmetPanel() }
        addChild(helmet)

        holder.zPosition = 5
        addChild(holder)

        nameLabel = makeLabel("", size: 30, color: .black)
        nameLabel.position = CGPoint(x: w / 2, y: h * (isLandscape ? 0.31 : 0.36))
        addChild(nameLabel)
        statsLabel = makeLabel("", size: 17, color: UIColor(white: 0.1, alpha: 1))
        statsLabel.position = CGPoint(x: w / 2, y: nameLabel.position.y - 30)
        addChild(statsLabel)

        let by = max(inset.bottom, 12) + 42
        let left2 = Button(text: "<", size: CGSize(width: 64, height: 64), fill: Theme.blue)
        left2.position = CGPoint(x: left + 20, y: by)
        left2.onTap = { [weak self] in self?.step(-1) }
        addChild(left2)
        let right2 = Button(text: ">", size: CGSize(width: 64, height: 64), fill: Theme.blue)
        right2.position = CGPoint(x: w - left - 20, y: by)
        right2.onTap = { [weak self] in self?.step(1) }
        addChild(right2)

        actionButton = Button(text: "", size: CGSize(width: min(w * 0.5, 240), height: 64), fill: Theme.green)
        actionButton.position = CGPoint(x: w / 2, y: by)
        actionButton.onTap = { [weak self] in self?.actionTapped() }
        addChild(actionButton)
    }

    private var bike: BikeSpec { Catalog.bikes[index] }

    private func step(_ d: Int) {
        index = (index + d + Catalog.bikes.count) % Catalog.bikes.count
        refresh()
    }

    private func actionTapped() {
        let b = bike
        if store.ownsBike(b.id) {
            store.selectedBike = b.id
        } else if store.money >= b.price {
            store.money -= b.price
            store.addBike(b.id)
            store.selectedBike = b.id
        } else {
            actionButton.shake()
            toast("NOT ENOUGH MONEY")
        }
        refresh()
    }

    private func refresh() {
        let b = bike
        moneyLabel.text = "$\(store.money)"
        nameLabel.text = b.name
        statsLabel.text = "POWER \(Int(b.power * 100))   TOP SPEED \(Int(b.topSpeed)) KM/H   SCORE x\(String(format: "%.1f", Double(b.scoreMult)))"
        if store.ownsBike(b.id) {
            if store.selectedBike == b.id {
                actionButton.setText("SELECTED"); actionButton.setFill(UIColor(white: 0.5, alpha: 1))
            } else {
                actionButton.setText("SELECT"); actionButton.setFill(Theme.green)
            }
        } else {
            actionButton.setText("BUY $\(b.price)"); actionButton.setFill(Theme.yellow)
            actionButton.label.fontColor = .black
        }
        if store.ownsBike(b.id) { actionButton.label.fontColor = .white }

        holder.removeAllChildren()
        let paint = Catalog.paints[min(store.selectedPaint, Catalog.paints.count - 1)].color
        let node = BikeNode(bike: b, paintColor: paint, helmetId: store.selectedHelmet, withRider: true)
        let s = min(size.width * 0.85 / 480, size.height * 0.30 / 260)
        node.setScale(s)
        node.position = CGPoint(x: size.width / 2 - 170 * s, y: size.height * (isLandscape ? 0.40 : 0.47) - 70 * s)
        holder.addChild(node)
        node.rearWheel.run(SKAction.repeatForever(SKAction.rotate(byAngle: -.pi * 2, duration: 2.0)))
        node.frontWheel.run(SKAction.repeatForever(SKAction.rotate(byAngle: -.pi * 2, duration: 2.0)))
    }

    // MARK: Panels (paint / helmet)
    private func showPaintPanel() {
        var items: [PanelItem] = []
        for (i, p) in Catalog.paints.enumerated() {
            items.append(PanelItem(color: p.color, price: p.price, owned: store.ownsPaint(i), selected: store.selectedPaint == i) { [weak self] in
                guard let self = self else { return }
                if self.buyIfNeeded(price: p.price, owned: self.store.ownsPaint(i), buy: { self.store.addPaint(i) }) {
                    self.store.selectedPaint = i
                }
                self.refresh()
                self.showPaintPanel()
            })
        }
        openPanel(title: "PAINT", items: items)
    }

    private func showHelmetPanel() {
        var items: [PanelItem] = []
        for hm in Catalog.helmets {
            var it = PanelItem(price: hm.price, owned: store.ownsHelmet(hm.id), selected: store.selectedHelmet == hm.id) { [weak self] in
                guard let self = self else { return }
                if self.buyIfNeeded(price: hm.price, owned: self.store.ownsHelmet(hm.id), buy: { self.store.addHelmet(hm.id) }) {
                    self.store.selectedHelmet = hm.id
                }
                self.refresh()
                self.showHelmetPanel()
            }
            if hm.id > 0, let t = Assets.texture("helmet_\(hm.id)") {
                it.texture = SKTexture(rect: CGRect(x: 0.36, y: 0.66, width: 0.28, height: 0.33), in: t)
            }
            items.append(it)
        }
        openPanel(title: "HELMET", items: items)
    }

    private func buyIfNeeded(price: Int, owned: Bool, buy: () -> Void) -> Bool {
        if owned { return true }
        if store.money >= price {
            store.money -= price
            buy()
            return true
        }
        toast("NOT ENOUGH MONEY")
        return false
    }

    private func openPanel(title: String, items: [PanelItem]) {
        closeOverlay()
        let root = SKNode()
        root.zPosition = 500
        let dim = SKShapeNode(rect: CGRect(origin: .zero, size: size))
        dim.fillColor = UIColor(white: 0, alpha: 0.6)
        dim.strokeColor = .clear
        root.addChild(dim)

        let cols = isLandscape ? 4 : 3
        let cell: CGFloat = isLandscape ? 78 : 96
        let gap: CGFloat = 12
        let rows = Int(ceil(Double(items.count) / Double(cols)))
        let pw = CGFloat(cols) * (cell + gap) + gap + 20
        let ph = CGFloat(rows) * (cell + gap) + 110
        let panel = SKShapeNode(rectOf: CGSize(width: pw, height: ph), cornerRadius: 22)
        panel.fillColor = Theme.panel
        panel.strokeColor = .black
        panel.lineWidth = 4
        panel.position = CGPoint(x: size.width / 2, y: size.height / 2)
        root.addChild(panel)

        let t = makeLabel(title, size: 34, color: Theme.yellow)
        t.position = CGPoint(x: 0, y: ph / 2 - 40)
        panel.addChild(t)

        let close = Button(text: "X", size: CGSize(width: 44, height: 44), fill: Theme.red)
        close.position = CGPoint(x: pw / 2 - 12, y: ph / 2 - 12)
        close.zPosition = 5
        close.onTap = { [weak self] in self?.closeOverlay() }
        panel.addChild(close)

        for (n, it) in items.enumerated() {
            let c = n % cols, r = n / cols
            let x = (CGFloat(c) - CGFloat(cols - 1) / 2) * (cell + gap)
            let y = ph / 2 - 84 - cell / 2 - CGFloat(r) * (cell + gap)
            let b = Button(text: "", size: CGSize(width: cell, height: cell), fill: it.selected ? Theme.green : Theme.darkBlue)
            b.position = CGPoint(x: x, y: y)
            b.label.fontSize = cell * 0.2
            b.label.position = CGPoint(x: 0, y: -cell * 0.33)
            b.setText(it.selected ? "ON" : (it.owned ? "SELECT" : "$\(it.price)"))
            if let col = it.color {
                let sw = SKShapeNode(rectOf: CGSize(width: cell * 0.5, height: cell * 0.5), cornerRadius: 10)
                sw.fillColor = col; sw.strokeColor = .black; sw.lineWidth = 3
                sw.position = CGPoint(x: 0, y: cell * 0.12); sw.zPosition = 2
                b.addChild(sw)
            } else if let tex = it.texture {
                let sp = SKSpriteNode(texture: tex)
                sp.size = CGSize(width: cell * 0.62, height: cell * 0.62)
                sp.position = CGPoint(x: 0, y: cell * 0.12); sp.zPosition = 2
                b.addChild(sp)
            } else {
                let none = makeLabel("-", size: cell * 0.4)
                none.position = CGPoint(x: 0, y: cell * 0.12); none.zPosition = 2
                b.addChild(none)
            }
            b.onTap = it.action
            panel.addChild(b)
        }
        addChild(root)
        modalRoot = root
    }
}
