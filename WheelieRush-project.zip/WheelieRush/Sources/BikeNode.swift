import SpriteKit
import UIKit

/// The bike + rider. The node's origin is the point where the REAR tyre touches the ground,
/// so rotating the node = doing a wheelie around the rear wheel.
/// All art layers (frame, paint, rider, helmet) share one 600x360 canvas, so they line up automatically.
final class BikeNode: SKNode {
    static let canvas = CGSize(width: 600, height: 360)
    static let wheelSize = CGSize(width: 140, height: 140)
    static let bodyCenter = CGPoint(x: 170, y: 140)   // canvas centre, relative to rear contact point
    static let rearAxle = CGPoint(x: 0, y: 70)
    static let frontAxle = CGPoint(x: 340, y: 70)

    let rearWheel: SKSpriteNode
    let frontWheel: SKSpriteNode
    let riderGroup = SKNode()
    let riderSprite: SKSpriteNode?

    init(bike: BikeSpec, paintColor: UIColor, helmetId: Int, withRider: Bool) {
        let id = bike.id
        rearWheel = Assets.sprite("wheel_\(id)", size: BikeNode.wheelSize, fallback: .black)
        frontWheel = Assets.sprite("wheel_\(id)", size: BikeNode.wheelSize, fallback: .black)
        if withRider {
            riderSprite = Assets.sprite("rider", size: BikeNode.canvas, fallback: .clear)
        } else {
            riderSprite = nil
        }
        super.init()

        rearWheel.position = BikeNode.rearAxle
        frontWheel.position = BikeNode.frontAxle
        rearWheel.zPosition = 0
        frontWheel.zPosition = 0
        addChild(rearWheel)
        addChild(frontWheel)

        let paint = Assets.sprite("bike_\(id)_paint", size: BikeNode.canvas, fallback: .clear)
        paint.position = BikeNode.bodyCenter
        paint.color = paintColor
        paint.colorBlendFactor = 1.0
        paint.zPosition = 1
        addChild(paint)

        let frame = Assets.sprite("bike_\(id)_frame", size: BikeNode.canvas, fallback: .clear)
        frame.position = BikeNode.bodyCenter
        frame.zPosition = 2
        addChild(frame)

        riderGroup.zPosition = 3
        addChild(riderGroup)
        if let r = riderSprite {
            r.position = BikeNode.bodyCenter
            riderGroup.addChild(r)
            if helmetId > 0 {
                let h = Assets.sprite("helmet_\(helmetId)", size: BikeNode.canvas, fallback: .clear)
                h.position = BikeNode.bodyCenter
                h.zPosition = 1
                riderGroup.addChild(h)
            }
        }
    }

    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func spinWheels(_ radians: CGFloat) {
        rearWheel.zRotation -= radians
        frontWheel.zRotation -= radians
    }
}
