import SpriteKit
import UIKit

enum Theme {
    static let fontName = "AvenirNext-Heavy"
    static let blue = UIColor(red: 0.16, green: 0.45, blue: 0.95, alpha: 1)
    static let darkBlue = UIColor(red: 0.05, green: 0.30, blue: 0.62, alpha: 1)
    static let green = UIColor(red: 0.15, green: 0.72, blue: 0.25, alpha: 1)
    static let red = UIColor(red: 0.85, green: 0.2, blue: 0.2, alpha: 1)
    static let purple = UIColor(red: 0.5, green: 0.3, blue: 0.8, alpha: 1)
    static let yellow = UIColor(red: 1.0, green: 0.93, blue: 0.2, alpha: 1)
    static let panel = UIColor(white: 0.16, alpha: 1)
    static let skyTop = UIColor(red: 0.30, green: 0.60, blue: 0.95, alpha: 1)
    static let skyBottom = UIColor(red: 0.62, green: 0.82, blue: 1.0, alpha: 1)

    static func gradient(top: UIColor, bottom: UIColor) -> SKTexture {
        let size = CGSize(width: 4, height: 256)
        let img = UIGraphicsImageRenderer(size: size).image { ctx in
            let cs = CGColorSpaceCreateDeviceRGB()
            if let g = CGGradient(colorsSpace: cs, colors: [top.cgColor, bottom.cgColor] as CFArray, locations: [0, 1]) {
                ctx.cgContext.drawLinearGradient(g, start: .zero, end: CGPoint(x: 0, y: size.height), options: [])
            }
        }
        return SKTexture(image: img)
    }
}

func makeLabel(_ text: String, size: CGFloat, color: UIColor = .white,
               align: SKLabelHorizontalAlignmentMode = .center) -> SKLabelNode {
    let l = SKLabelNode(fontNamed: Theme.fontName)
    l.text = text
    l.fontSize = size
    l.fontColor = color
    l.horizontalAlignmentMode = align
    l.verticalAlignmentMode = .center
    return l
}

func outlinedLabel(_ text: String, size: CGFloat, color: UIColor) -> SKNode {
    let node = SKNode()
    let o = max(2, size * 0.05)
    for (dx, dy) in [(-o, 0), (o, 0), (0, -o), (0, o), (o, o), (-o, -o), (o, -o), (-o, o)] as [(CGFloat, CGFloat)] {
        let l = makeLabel(text, size: size, color: .black)
        l.position = CGPoint(x: dx, y: dy)
        node.addChild(l)
    }
    node.addChild(makeLabel(text, size: size, color: color))
    return node
}

final class Button: SKNode {
    let bg: SKShapeNode
    let label: SKLabelNode
    let size: CGSize
    var onTap: (() -> Void)?
    var isEnabled = true

    init(text: String, size: CGSize, fill: UIColor = Theme.blue, textColor: UIColor = .white, fontSize: CGFloat? = nil) {
        self.size = size
        bg = SKShapeNode(rectOf: size, cornerRadius: min(size.height * 0.3, 18))
        label = makeLabel(text, size: fontSize ?? size.height * 0.45, color: textColor)
        super.init()
        bg.fillColor = fill
        bg.strokeColor = .black
        bg.lineWidth = 3
        addChild(bg)
        label.zPosition = 1
        addChild(label)
        fit()
    }

    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func fit() {
        label.setScale(1)
        let w = label.frame.width
        let limit = size.width * 0.9
        if w > limit && w > 0 { label.setScale(limit / w) }
    }

    func setText(_ t: String) { label.text = t; fit() }
    func setFill(_ c: UIColor) { bg.fillColor = c }

    func setPressed(_ p: Bool) {
        removeAction(forKey: "press")
        run(SKAction.scale(to: p ? 0.94 : 1.0, duration: 0.06), withKey: "press")
    }
}

extension SKNode {
    func shake() {
        let a = SKAction.sequence([
            SKAction.moveBy(x: -8, y: 0, duration: 0.04), SKAction.moveBy(x: 16, y: 0, duration: 0.06),
            SKAction.moveBy(x: -16, y: 0, duration: 0.06), SKAction.moveBy(x: 8, y: 0, duration: 0.04)
        ])
        run(a)
    }
}

class BaseScene: SKScene {
    var modalRoot: SKNode?
    private var pressed: Button?

    override init(size: CGSize) {
        super.init(size: size)
        scaleMode = .aspectFill
        anchorPoint = .zero
    }

    required init?(coder aDecoder: NSCoder) { super.init(coder: aDecoder) }

    var inset: UIEdgeInsets { view?.safeAreaInsets ?? .zero }
    var isLandscape: Bool { size.width > size.height }

    func addBackground() {
        let tex = Assets.texture("sky") ?? Theme.gradient(top: Theme.skyTop, bottom: Theme.skyBottom)
        let s = SKSpriteNode(texture: tex)
        s.size = size
        s.position = CGPoint(x: size.width / 2, y: size.height / 2)
        s.zPosition = -100
        addChild(s)
    }

    func button(at p: CGPoint) -> Button? {
        for n in nodes(at: p) {
            var cur: SKNode? = n
            while let c = cur {
                if let b = c as? Button, !b.isHidden, b.isEnabled {
                    if let m = modalRoot, !b.inParentHierarchy(m) { break }
                    return b
                }
                cur = c.parent
            }
        }
        return nil
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        pressed?.setPressed(false)
        pressed = button(at: t.location(in: self))
        pressed?.setPressed(true)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, let p = pressed else { return }
        let hit = button(at: t.location(in: self))
        p.setPressed(false)
        pressed = nil
        if hit === p { p.onTap?() }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        pressed?.setPressed(false)
        pressed = nil
    }

    func toast(_ text: String) {
        let l = makeLabel(text, size: 24, color: Theme.yellow)
        l.position = CGPoint(x: size.width / 2, y: size.height * 0.62)
        l.zPosition = 900
        addChild(l)
        l.run(SKAction.sequence([
            SKAction.group([SKAction.moveBy(x: 0, y: 40, duration: 0.9), SKAction.fadeOut(withDuration: 0.9)]),
            SKAction.removeFromParent()
        ]))
    }

    @discardableResult
    func showOverlay(title: String, lines: [String], buttons: [(String, UIColor, () -> Void)]) -> SKNode {
        closeOverlay()
        let root = SKNode()
        root.zPosition = 500
        let dim = SKShapeNode(rect: CGRect(origin: .zero, size: size))
        dim.fillColor = UIColor(white: 0, alpha: 0.6)
        dim.strokeColor = .clear
        root.addChild(dim)

        let bw = min(size.width * 0.7, 300)
        let bh: CGFloat = 52
        let pw = min(size.width * 0.88, 380)
        let ph = 120 + CGFloat(lines.count) * 32 + CGFloat(buttons.count) * (bh + 12)
        let panel = SKShapeNode(rectOf: CGSize(width: pw, height: ph), cornerRadius: 22)
        panel.fillColor = Theme.panel
        panel.strokeColor = .black
        panel.lineWidth = 4
        panel.position = CGPoint(x: size.width / 2, y: size.height / 2)
        root.addChild(panel)

        var y = ph / 2 - 46
        let t = makeLabel(title, size: 38, color: Theme.yellow)
        t.position = CGPoint(x: 0, y: y)
        panel.addChild(t)
        y -= 50
        for line in lines {
            let l = makeLabel(line, size: 24)
            l.position = CGPoint(x: 0, y: y)
            panel.addChild(l)
            y -= 32
        }
        y -= 8 + bh / 2
        for (text, color, action) in buttons {
            let b = Button(text: text, size: CGSize(width: bw, height: bh), fill: color)
            b.position = CGPoint(x: 0, y: y)
            b.onTap = action
            panel.addChild(b)
            y -= bh + 12
        }
        addChild(root)
        modalRoot = root
        return root
    }

    func closeOverlay() {
        modalRoot?.removeFromParent()
        modalRoot = nil
    }
}
