import UIKit

enum Screen { case menu, garage, options, game }

struct BikeSpec {
    let id: Int
    let name: String
    let price: Int
    let power: CGFloat      // how strongly GAS lifts the front wheel
    let topSpeed: CGFloat   // km/h
    let scoreMult: CGFloat  // score multiplier
}

struct PaintSpec { let name: String; let color: UIColor; let price: Int }
struct HelmetSpec { let id: Int; let name: String; let price: Int }
struct Ratio { let name: String; let value: CGFloat? }

enum Catalog {
    static let bikes: [BikeSpec] = [
        BikeSpec(id: 1, name: "CITY MOPED",   price: 0,    power: 1.00, topSpeed: 90,  scoreMult: 1.0),
        BikeSpec(id: 2, name: "DIRT RIPPER",  price: 800,  power: 1.15, topSpeed: 120, scoreMult: 1.3),
        BikeSpec(id: 3, name: "STREET BLADE", price: 1500, power: 1.30, topSpeed: 160, scoreMult: 1.7)
    ]

    static let paints: [PaintSpec] = [
        PaintSpec(name: "WHITE",  color: UIColor(white: 0.97, alpha: 1), price: 0),
        PaintSpec(name: "BLACK",  color: UIColor(white: 0.12, alpha: 1), price: 0),
        PaintSpec(name: "RED",    color: UIColor(red: 0.92, green: 0.12, blue: 0.12, alpha: 1), price: 250),
        PaintSpec(name: "GREEN",  color: UIColor(red: 0.15, green: 0.80, blue: 0.20, alpha: 1), price: 250),
        PaintSpec(name: "YELLOW", color: UIColor(red: 1.00, green: 0.90, blue: 0.10, alpha: 1), price: 250),
        PaintSpec(name: "ORANGE", color: UIColor(red: 1.00, green: 0.50, blue: 0.05, alpha: 1), price: 250),
        PaintSpec(name: "BLUE",   color: UIColor(red: 0.10, green: 0.35, blue: 0.95, alpha: 1), price: 250)
    ]

    static let helmets: [HelmetSpec] = [
        HelmetSpec(id: 0, name: "NONE",  price: 0),
        HelmetSpec(id: 1, name: "OPEN",  price: 0),
        HelmetSpec(id: 2, name: "FULL",  price: 200),
        HelmetSpec(id: 3, name: "CROSS", price: 300)
    ]

    static func bike(_ id: Int) -> BikeSpec { bikes.first { $0.id == id } ?? bikes[0] }
}

final class Store {
    static let shared = Store()
    private let d = UserDefaults.standard

    // Screen shapes: value = width / height in landscape (inverted in portrait). nil = fill the whole screen.
    static let ratios: [Ratio] = [
        Ratio(name: "FULL", value: nil),
        Ratio(name: "21:9", value: 21.0 / 9.0),
        Ratio(name: "16:9", value: 16.0 / 9.0),
        Ratio(name: "3:2",  value: 3.0 / 2.0),
        Ratio(name: "4:3",  value: 4.0 / 3.0)
    ]

    var money: Int {
        get { (d.object(forKey: "money") as? Int) ?? 300 }
        set { d.set(max(0, newValue), forKey: "money") }
    }
    var best: Int {
        get { d.integer(forKey: "best") }
        set { d.set(newValue, forKey: "best") }
    }
    var selectedBike: Int {
        get { (d.object(forKey: "selBike") as? Int) ?? 1 }
        set { d.set(newValue, forKey: "selBike") }
    }
    var selectedPaint: Int {
        get { d.integer(forKey: "selPaint") }
        set { d.set(newValue, forKey: "selPaint") }
    }
    var selectedHelmet: Int {
        get { (d.object(forKey: "selHelmet") as? Int) ?? 1 }
        set { d.set(newValue, forKey: "selHelmet") }
    }
    var landscape: Bool {
        get { d.bool(forKey: "landscape") }
        set { d.set(newValue, forKey: "landscape") }
    }
    var ratioIndex: Int {
        get { min(max(d.integer(forKey: "ratio"), 0), Store.ratios.count - 1) }
        set { d.set(newValue, forKey: "ratio") }
    }

    private func owned(_ key: String, _ defaults: [Int]) -> Set<Int> {
        Set((d.array(forKey: key) as? [Int]) ?? defaults)
    }
    private func addOwned(_ key: String, _ defaults: [Int], _ id: Int) {
        var s = owned(key, defaults); s.insert(id); d.set(Array(s), forKey: key)
    }

    func ownsBike(_ id: Int) -> Bool { owned("ownedBikes", [1]).contains(id) }
    func ownsPaint(_ i: Int) -> Bool { owned("ownedPaints", [0, 1]).contains(i) }
    func ownsHelmet(_ id: Int) -> Bool { owned("ownedHelmets", [0, 1]).contains(id) }
    func addBike(_ id: Int) { addOwned("ownedBikes", [1], id) }
    func addPaint(_ i: Int) { addOwned("ownedPaints", [0, 1], i) }
    func addHelmet(_ id: Int) { addOwned("ownedHelmets", [0, 1], id) }
}
