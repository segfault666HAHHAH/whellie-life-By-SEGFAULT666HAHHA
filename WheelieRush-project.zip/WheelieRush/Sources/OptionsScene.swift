import SpriteKit

final class OptionsScene: BaseScene {
    private let store = Store.shared
    private var ratioButtons: [Button] = []
    private var landscapeButton: Button!

    override func didMove(to view: SKView) {
        addBackground()
        let w = size.width, h = size.height

        let title = outlinedLabel("OPTIONS", size: min(w * 0.12, 56), color: Theme.yellow)
        title.position = CGPoint(x: w / 2, y: h - max(inset.top, 16) - 50)
        addChild(title)

        // Fullscreen = landscape
        let bw = min(w * 0.8, 420)
        landscapeButton = Button(text: "", size: CGSize(width: bw, height: 58), fill: Theme.blue)
        landscapeButton.position = CGPoint(x: w / 2, y: h * (isLandscape ? 0.62 : 0.68))
        landscapeButton.onTap = { [weak self] in self?.toggleLandscape() }
        addChild(landscapeButton)
        updateLandscapeText()

        // Screen shape
        let lab = makeLabel("SCREEN SHAPE", size: 24, color: .black)
        lab.position = CGPoint(x: w / 2, y: h * (isLandscape ? 0.50 : 0.56))
        addChild(lab)

        let n = Store.ratios.count
        let cols = isLandscape ? n : 3
        let bwR = min((w - 40) / CGFloat(cols) - 10, 110)
        let rowsCount = Int(ceil(Double(n) / Double(cols)))
        for (i, r) in Store.ratios.enumerated() {
            let c = i % cols, row = i / cols
            let itemsInRow = min(cols, n - row * cols)
            let x = w / 2 + (CGFloat(c) - CGFloat(itemsInRow - 1) / 2) * (bwR + 10)
            let y = lab.position.y - 46 - CGFloat(row) * 58
            let b = Button(text: r.name, size: CGSize(width: bwR, height: 48), fill: Theme.darkBlue)
            b.position = CGPoint(x: x, y: y)
            b.onTap = { [weak self] in self?.pick(i) }
            addChild(b)
            ratioButtons.append(b)
        }
        _ = rowsCount
        updateRatioColors()

        let hint = makeLabel("FULL = stretch to the whole screen", size: 16, color: UIColor(white: 0.15, alpha: 1))
        hint.position = CGPoint(x: w / 2, y: max(inset.bottom, 12) + 100)
        addChild(hint)

        let back = Button(text: "BACK", size: CGSize(width: min(w * 0.5, 220), height: 56), fill: Theme.blue)
        back.position = CGPoint(x: w / 2, y: max(inset.bottom, 12) + 44)
        back.onTap = { Router.shared.show(.menu) }
        addChild(back)
    }

    private func updateLandscapeText() {
        landscapeButton.setText(store.landscape ? "FULLSCREEN (LANDSCAPE): ON" : "FULLSCREEN (LANDSCAPE): OFF")
        landscapeButton.setFill(store.landscape ? Theme.green : Theme.blue)
    }

    private func updateRatioColors() {
        for (i, b) in ratioButtons.enumerated() {
            b.setFill(i == store.ratioIndex ? Theme.green : Theme.darkBlue)
        }
    }

    private func toggleLandscape() {
        store.landscape.toggle()
        updateLandscapeText()
        Router.shared.applyOrientation()   // screen rotates, this scene is rebuilt automatically
    }

    private func pick(_ i: Int) {
        store.ratioIndex = i
        updateRatioColors()
        Router.shared.relayout()           // re-fits the game into the chosen shape
    }
}
