WHEELIE RUSH - ASSETS FOLDER
============================
Every picture in the game is a PNG in this folder. Replace a file (same name, same
pixel size) and the game uses your picture instead.

TWO WAYS TO CUSTOMISE
1) Before building: replace the PNGs in this "Assets" folder in your GitHub repo,
   then let GitHub build a new .ipa. The Assets folder is packed inside the .ipa.
2) After installing (no rebuild): open the Files app > On My iPhone > Wheelie Rush >
   Assets, and drop PNGs with the same names there. Files there win over the built-in ones.
   (If the folder is empty/missing, restart the game once.)

FILES
 wheel_1/2/3.png          140x140   wheel for each bike (spins while riding)
 bike_N_frame.png         600x360   bike outline/parts. Paint areas are see-through.
 bike_N_paint.png         600x360   the paintable parts, drawn WHITE (the game tints them)
 rider.png                600x360   rider (same canvas as the bike!)
 helmet_1/2/3.png         600x360   helmets (same canvas, head near x=302 y=58)
 road.png                 1024x320  road tile, repeats left-right
 bg_far.png               1024x400  far scenery tile, repeats left-right
 sky.png (optional)       any       background picture; add it yourself

TIPS
 - Keep the rear wheel centre at (130,250) and the front wheel centre at (470,250)
   on the 600x360 canvas so everything lines up.
 - Left and right edges of road.png / bg_far.png should match so it tiles cleanly.
 - Missing files are fine; the game draws a plain shape instead.
